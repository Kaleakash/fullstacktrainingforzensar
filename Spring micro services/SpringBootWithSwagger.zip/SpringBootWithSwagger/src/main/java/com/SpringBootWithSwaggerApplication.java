package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWithSwaggerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWithSwaggerApplication.class, args);
	}

}
